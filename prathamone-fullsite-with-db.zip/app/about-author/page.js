
export default function AboutAuthor(){
  return (
    <section className="max-w-6xl mx-auto p-6">
      <h2 className="text-2xl font-semibold">About the Author</h2>
      <p className="mt-2 text-gray-700">Jawahar R. Mallah — short bio goes here.</p>
    </section>
  )
}
