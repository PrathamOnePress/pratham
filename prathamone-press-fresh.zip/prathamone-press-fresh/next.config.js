/** Minimal next config */
const nextConfig = { reactStrictMode: true, experimental: { appDir: true } }
module.exports = nextConfig
