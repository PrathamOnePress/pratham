# PrathamOne Press — Fresh Starter (Next.js + Supabase)

Quickstart:
1. Copy `.env.local.example` to `.env.local` and fill values.
2. `npm install`
3. `npm run dev`
