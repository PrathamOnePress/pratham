# Prathamone Publications (Production-ready)

**Author:** Jawahar R. Mallah
**Email:** jawahar.mallah@gmail.com

## Setup (local)
1. `npm install`
2. `npm run dev` (runs Next.js dev server)
3. For Firebase emulator (optional): `npm run firebase:serve`

## Deploy (Vercel)
1. Push repo to GitHub
2. Import project in Vercel and deploy (Next.js is auto-detected)
