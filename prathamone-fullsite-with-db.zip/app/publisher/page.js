
export default function Publisher(){
  return (
    <section className="max-w-6xl mx-auto p-6">
      <h2 className="text-2xl font-semibold">Publisher</h2>
      <p className="mt-2 text-gray-700">Information about PrathamOne publishing services.</p>
    </section>
  )
}
