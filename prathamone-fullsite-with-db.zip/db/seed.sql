
INSERT INTO publishers (name, website) VALUES ('PrathamOne Press','https://prathamone.com');
INSERT INTO books (title, author, description, published_date) VALUES
('GanitSūtram — The Golden Book of Vedic Mathematics','Jawahar R. Mallah','A practical guide to Vedic mathematics', '2025-01-01'),
('Coder who fears before Ai','Jawahar R. Mallah','Memoir and thoughts on coding in AI era','2024-10-10');
